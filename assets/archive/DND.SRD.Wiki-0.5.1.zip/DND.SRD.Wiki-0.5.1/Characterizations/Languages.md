# Languages

Your race indicates the languages your character can speak by default, and your background might give you access to one or more additional languages of your choice. Note these languages on your character sheet.

Choose your languages from the Standard Languages table, or choose one that is common in your campaign. With your GM's permission, you can instead choose a language from the Exotic Languages table or a secret language, such as thieves' cant or the tongue of druids.

Some of these languages are actually families of languages with many dialects. For example, the Primordial language includes the Auran, Aquan, Ignan, and Terran dialects, one for each of the four elemental planes. Creatures that speak different dialects of the same language can communicate with one another.

**Table- Standard Languages**

| Language | Typical Speakers | Script   |
|----------|------------------|----------|
| Common   | Humans           | Common   |
| Dwarvish | Dwarves          | Dwarvish |
| Elvish   | Elves            | Elvish   |
| Giant    | Ogres, giants    | Dwarvish |
| Gnomish  | Gnomes           | Dwarvish |
| Goblin   | Goblinoids       | Dwarvish |
| Halfling | Halflings        | Common   |
| Orc      | Orcs             | Dwarvish |
|          |                  |          |

**Table- Exotic Languages**

| Language    | Typical Speakers    | Script    |
|-------------|---------------------|-----------|
| Abyssal     | Demons              | Infernal  |
| Celestial   | Celestials          | Celestial |
| Draconic    | Dragons, dragonborn | Draconic  |
| Deep Speech | Aboleths, cloakers  | -         |
| Infernal    | Devils              | Infernal  |
| Primordial  | Elementals          | Dwarvish  |
| Sylvan      | Fey creatures       | Elvish    |
| Undercommon | Underworld traders  | Elvish    |
|             |                     |           |

# Inspiration

Inspiration is a rule the game master can use to reward you for playing your character in a way that's true to his or her personality traits, ideal, bond, and flaw. By using inspiration, you can draw on your personality trait of compassion for the downtrodden to give you an edge in negotiating with the Beggar Prince. Or inspiration can let you call on your bond to the defense of your home village to push past the effect of a spell that has been laid on you.

## Gaining Inspiration

Your GM can choose to give you inspiration for a variety of reasons. Typically, GMs award it when you play out your personality traits, give in to the drawbacks presented by a flaw or bond, and otherwise portray your character in a compelling way. Your GM will tell you how you can earn inspiration in the game.

You either have inspiration or you don't - you can't stockpile multiple "inspirations" for later use.

## Using Inspiration

If you have inspiration, you can expend it when you make an attack roll, saving throw, or ability check. Spending your inspiration gives you advantage on that roll.

Additionally, if you have inspiration, you can reward another player for good roleplaying, clever thinking, or simply doing something exciting in the game. When another player character does something that really contributes to the story in a fun and interesting way, you can give up your inspiration to give that character inspiration.