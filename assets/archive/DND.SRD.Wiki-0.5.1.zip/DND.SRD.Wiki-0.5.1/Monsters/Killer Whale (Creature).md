### Killer Whale

*Huge beast, unaligned*

**Armor Class** 12 (natural armor)

**Hit Points** 90 (12d12+12)

**Speed** 0 ft., swim 60 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 19 (+4) | 10 (+0) | 13 (+1) | 3 (-4) | 12 (+1) | 7 (-2) |

**Skills** Perception +3

**Senses** blindsight 120 ft., passive Perception 13

**Languages** -

**Challenge** 3 (700 XP)

***Echolocation***. The whale can't use its blindsight while deafened.

***Hold Breath***. The whale can hold its breath for 30 minutes.

***Keen Hearing***. The whale has advantage on Wisdom (Perception) checks that rely on hearing.

###### Actions

***Bite***. *Melee Weapon Attack:* +6 to hit, reach 5 ft., one target. *Hit:* 21 (5d6+4) piercing damage.