### Hyena

*Medium beast, unaligned*

**Armor Class** 11

**Hit Points** 5 (1d8+1)

**Speed** 50 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 11 (+0) | 13 (+1) | 12 (+1) | 2 (-4) | 12 (+1) | 5 (-3) |

**Skills** Perception +3

**Senses** passive Perception 13

**Languages** -

**Challenge** 0 (10 XP)

***Pack Tactics***. The hyena has advantage on an attack roll against a creature if at least one of the hyena's allies is within 5 feet of the creature and the ally isn't incapacitated.

###### Actions

***Bite***. *Melee Weapon Attack:* +2 to hit, reach 5 ft., one target. *Hit:* 3 (1d6) piercing damage.