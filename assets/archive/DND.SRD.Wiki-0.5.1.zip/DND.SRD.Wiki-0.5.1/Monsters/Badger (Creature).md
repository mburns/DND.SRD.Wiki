### Badger

*Tiny beast, unaligned*

**Armor Class** 10

**Hit Points** 3 (1d4+1)

**Speed** 20 ft., burrow 5 ft.

| STR    | DEX     | CON     | INT    | WIS     | CHA    |
|--------|---------|---------|--------|---------|--------|
| 4 (-3) | 11 (+0) | 12 (+1) | 2 (-4) | 12 (+1) | 5 (-3) |

**Senses** darkvision 30 ft., passive Perception 11

**Languages** -

**Challenge** 0 (10 XP)

***Keen Smell***. The badger has advantage on Wisdom (Perception) checks that rely on smell.

###### Actions

***Bite***. *Melee Weapon Attack:* +2 to hit, reach 5 ft., one target. *Hit:* 1 piercing damage.