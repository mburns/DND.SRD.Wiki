### Guard

*Medium humanoid (any race), any alignment*

**Armor Class** 16 (chain shirt, shield)

**Hit Points** 11 (2d8 + 2)

**Speed** 30 ft.

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 13 (+1) | 12 (+1) | 12 (+1) | 10 (+0) | 11 (+0) | 10 (+0) |

**Skills** Perception +2

**Senses** passive Perception 12

**Languages** any one language (usually Common)

**Challenge** 1/8 (25 XP)

###### Actions

***Spear***. *Melee or Ranged Weapon Attack:* +3 to hit, reach 5 ft. or range 20/60 ft., one target. *Hit:* 4 (1d6 + 1) piercing damage, or 5 (1d8 + 1) piercing damage if used with two hands to make a melee attack.

**Guards** include members of a city watch, sentries in a citadel or fortified town, and the bodyguards of merchants and nobles.