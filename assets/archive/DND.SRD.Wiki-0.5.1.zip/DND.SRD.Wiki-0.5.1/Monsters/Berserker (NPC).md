### Berserker

*Medium humanoid (any race), any chaotic alignment*

**Armor Class** 13 (hide armor)

**Hit Points** 67 (9d8 + 27)

**Speed** 30 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 16 (+3) | 12 (+1) | 17 (+3) | 9 (-1) | 11 (+0) | 9 (-1) |

**Senses** passive Perception 10

**Languages** any one language (usually Common)

**Challenge** 2 (450 XP)

***Reckless***. At the start of its turn, the berserker can gain advantage on all melee weapon attack rolls during that turn, but attack rolls against it have advantage until the start of its next turn.

###### Actions

***Greataxe***. *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 9 (1d12 + 3) slashing damage.

Hailing from uncivilized lands, unpredictable **berserkers** come together in war parties and seek conflict wherever they can find it.